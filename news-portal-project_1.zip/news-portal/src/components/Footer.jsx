const Footer = () => {
  return (
    <footer className="bg-slate-800 text-white py-6 mt-8">
      <div className="container mx-auto px-4 text-center">
        <p className="text-sm">
          Desenvolvido por: João Silva (RA: 12345678), Maria Santos (RA: 87654321), Pedro Costa (RA: 11223344)
        </p>
        <p className="text-xs mt-2 text-gray-400">
          © 2024 NewsPortal - Portal de Notícias
        </p>
      </div>
    </footer>
  )
}

export default Footer

