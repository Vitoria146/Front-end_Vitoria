import { Link } from 'react-router-dom'
import { Newspaper } from 'lucide-react'

const Header = () => {
  return (
    <header className="bg-slate-800 text-white shadow-lg">
      <div className="container mx-auto px-4 py-4">
        <Link to="/" className="flex items-center space-x-2 hover:opacity-80 transition-opacity">
          <Newspaper className="h-8 w-8" />
          <h1 className="text-2xl font-bold">NewsPortal</h1>
        </Link>
      </div>
    </header>
  )
}

export default Header

