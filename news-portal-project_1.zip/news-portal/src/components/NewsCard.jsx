import { Link } from 'react-router-dom'
import { Calendar, Tag } from 'lucide-react'
import { Card, CardContent, CardHeader } from '@/components/ui/card'

const NewsCard = ({ news }) => {
  const truncateContent = (content, maxLength = 50) => {
    if (content.length <= maxLength) return content
    return content.substring(0, maxLength) + '...'
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('pt-BR')
  }

  return (
    <Card className="hover:shadow-lg transition-shadow duration-300 h-full">
      <CardHeader className="p-0">
        <div className="aspect-video bg-gradient-to-br from-blue-500 to-purple-600 rounded-t-lg flex items-center justify-center">
          <div className="text-white text-6xl opacity-20">📰</div>
        </div>
      </CardHeader>
      <CardContent className="p-6 flex flex-col h-full">
        <div className="flex-1">
          <h3 className="text-xl font-semibold mb-2 line-clamp-2 hover:text-blue-600 transition-colors">
            <Link to={`/news/${news.id}`}>
              {news.titulo}
            </Link>
          </h3>
          
          <div className="flex items-center text-sm text-gray-500 mb-3">
            <Calendar className="h-4 w-4 mr-1" />
            <span>{formatDate(news.data)}</span>
          </div>
          
          <p className="text-gray-600 mb-4 line-clamp-3">
            {truncateContent(news.conteudo)}
          </p>
        </div>
        
        <div className="flex flex-wrap gap-2 mt-auto">
          {news.categorias.map((categoria, index) => (
            <span
              key={index}
              className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800"
            >
              <Tag className="h-3 w-3 mr-1" />
              {categoria}
            </span>
          ))}
        </div>
      </CardContent>
    </Card>
  )
}

export default NewsCard

