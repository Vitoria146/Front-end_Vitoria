// Mock data for news articles
export const newsData = [
  {
    id: 1,
    titulo: "Account boy little hair truth soon.",
    data: "2024-01-15",
    conteudo: "Accusamus dolorem sunt facilis dolore. Assumenda magis accusamus sit lorem ipsum dolor sit amet consectetur adipiscing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    imagem: "/src/assets/news1.jpg",
    categorias: ["Tecnologia", "Inovação"],
    comentarios: [
      { nome: "João Silva", texto: "Muito interessante este artigo!" },
      { nome: "Maria Santos", texto: "Concordo plenamente com a análise." }
    ]
  },
  {
    id: 2,
    titulo: "Breakthrough in Artificial Intelligence Research",
    data: "2024-01-14",
    conteudo: "Scientists have made significant progress in developing more efficient AI algorithms that could revolutionize the way we interact with technology in our daily lives.",
    imagem: "/src/assets/news2.jpg",
    categorias: ["Inteligência Artificial", "Pesquisa"],
    comentarios: [
      { nome: "Pedro Costa", texto: "O futuro chegou!" },
      { nome: "Ana Oliveira", texto: "Impressionante o avanço da tecnologia." }
    ]
  },
  {
    id: 3,
    titulo: "Climate Change Solutions Gaining Momentum",
    data: "2024-01-13",
    conteudo: "New renewable energy technologies are showing promising results in reducing carbon emissions and providing sustainable alternatives to fossil fuels.",
    imagem: "/src/assets/news3.jpg",
    categorias: ["Meio Ambiente", "Sustentabilidade"],
    comentarios: [
      { nome: "Carlos Mendes", texto: "Precisamos de mais iniciativas assim." }
    ]
  },
  {
    id: 4,
    titulo: "Space Exploration Reaches New Milestones",
    data: "2024-01-12",
    conteudo: "Recent missions to Mars have provided valuable data about the planet's composition and potential for supporting life in the future.",
    imagem: "/src/assets/news4.jpg",
    categorias: ["Espaço", "Ciência"],
    comentarios: [
      { nome: "Lucia Ferreira", texto: "Fascinante! Mal posso esperar pelas próximas descobertas." }
    ]
  },
  {
    id: 5,
    titulo: "Healthcare Innovation Transforms Patient Care",
    data: "2024-01-11",
    conteudo: "New medical technologies are improving diagnosis accuracy and treatment effectiveness, leading to better patient outcomes worldwide.",
    imagem: "/src/assets/news5.jpg",
    categorias: ["Saúde", "Medicina"],
    comentarios: [
      { nome: "Roberto Lima", texto: "Excelente notícia para a área médica." },
      { nome: "Fernanda Rocha", texto: "Isso vai salvar muitas vidas." }
    ]
  },
  {
    id: 6,
    titulo: "Economic Markets Show Strong Recovery",
    data: "2024-01-10",
    conteudo: "Global financial markets are demonstrating resilience and growth, with technology stocks leading the recovery in multiple sectors.",
    imagem: "/src/assets/news6.jpg",
    categorias: ["Economia", "Finanças"],
    comentarios: [
      { nome: "Marcos Alves", texto: "Boas notícias para os investidores." }
    ]
  },
  {
    id: 7,
    titulo: "Educational Technology Revolutionizes Learning",
    data: "2024-01-09",
    conteudo: "Virtual reality and AI-powered platforms are creating immersive learning experiences that enhance student engagement and comprehension.",
    imagem: "/src/assets/news7.jpg",
    categorias: ["Educação", "Tecnologia"],
    comentarios: [
      { nome: "Sandra Dias", texto: "O futuro da educação está aqui!" }
    ]
  },
  {
    id: 8,
    titulo: "Sustainable Agriculture Feeds Growing Population",
    data: "2024-01-08",
    conteudo: "Innovative farming techniques and biotechnology are helping farmers produce more food while reducing environmental impact.",
    imagem: "/src/assets/news8.jpg",
    categorias: ["Agricultura", "Sustentabilidade"],
    comentarios: [
      { nome: "José Barbosa", texto: "Muito importante para o futuro da alimentação." }
    ]
  },
  {
    id: 9,
    titulo: "Transportation Evolution: Electric and Autonomous",
    data: "2024-01-07",
    conteudo: "The automotive industry is rapidly transitioning to electric vehicles and autonomous driving technology, reshaping urban mobility.",
    imagem: "/src/assets/news9.jpg",
    categorias: ["Transporte", "Tecnologia"],
    comentarios: [
      { nome: "Patricia Gomes", texto: "Ansioso para dirigir um carro autônomo!" }
    ]
  },
  {
    id: 10,
    titulo: "Cybersecurity Advances Protect Digital Infrastructure",
    data: "2024-01-06",
    conteudo: "New security protocols and AI-driven threat detection systems are strengthening defenses against cyber attacks and data breaches.",
    imagem: "/src/assets/news10.jpg",
    categorias: ["Segurança", "Tecnologia"],
    comentarios: [
      { nome: "Ricardo Souza", texto: "Segurança digital é fundamental nos dias de hoje." },
      { nome: "Camila Torres", texto: "Excelente iniciativa para proteger nossos dados." }
    ]
  }
];

