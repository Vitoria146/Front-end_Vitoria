import { useState, useMemo } from 'react'
import { newsData } from '../data/newsData'
import NewsCard from '../components/NewsCard'
import SearchBar from '../components/SearchBar'

const HomePage = () => {
  const [searchTerm, setSearchTerm] = useState('')

  const filteredNews = useMemo(() => {
    if (!searchTerm.trim()) {
      return newsData
    }

    const searchLower = searchTerm.toLowerCase()
    return newsData.filter(news => 
      news.titulo.toLowerCase().includes(searchLower) ||
      news.conteudo.toLowerCase().includes(searchLower) ||
      news.categorias.some(categoria => 
        categoria.toLowerCase().includes(searchLower)
      )
    )
  }, [searchTerm])

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold text-gray-800 mb-4">
          Bem-vindo ao NewsPortal
        </h1>
        <p className="text-xl text-gray-600">
          Fique por dentro das últimas notícias e acontecimentos
        </p>
      </div>

      <SearchBar 
        searchTerm={searchTerm}
        onSearchChange={setSearchTerm}
      />

      {filteredNews.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">📰</div>
          <h2 className="text-2xl font-semibold text-gray-700 mb-2">
            Nenhum artigo encontrado
          </h2>
          <p className="text-gray-500">
            Tente ajustar sua busca ou navegue pelas categorias disponíveis.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredNews.map(news => (
            <NewsCard key={news.id} news={news} />
          ))}
        </div>
      )}
    </div>
  )
}

export default HomePage

