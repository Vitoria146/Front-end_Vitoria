import { useParams, Link, useNavigate } from 'react-router-dom'
import { ArrowLeft, Calendar, Tag } from 'lucide-react'
import { newsData } from '../data/newsData'
import Comments from '../components/Comments'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader } from '@/components/ui/card'

const NewsDetailPage = () => {
  const { id } = useParams()
  const navigate = useNavigate()
  const news = newsData.find(item => item.id === parseInt(id))

  if (!news) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <div className="text-6xl mb-4">❌</div>
        <h1 className="text-3xl font-bold text-gray-800 mb-4">
          Notícia não encontrada
        </h1>
        <p className="text-gray-600 mb-6">
          A notícia que você está procurando não existe ou foi removida.
        </p>
        <Button onClick={() => navigate('/')} className="inline-flex items-center">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Voltar para Home
        </Button>
      </div>
    )
  }

  const formatDate = (dateString) => {
    const date = new Date(dateString)
    return date.toLocaleDateString('pt-BR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    })
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <Button 
        onClick={() => navigate('/')} 
        variant="outline" 
        className="mb-6 inline-flex items-center"
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Voltar para Home
      </Button>

      <Card>
        <CardHeader className="p-0">
          <div className="aspect-video bg-gradient-to-br from-blue-500 to-purple-600 rounded-t-lg flex items-center justify-center">
            <div className="text-white text-8xl opacity-20">📰</div>
          </div>
        </CardHeader>
        <CardContent className="p-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-4 leading-tight">
            {news.titulo}
          </h1>

          <div className="flex items-center text-gray-500 mb-6">
            <Calendar className="h-5 w-5 mr-2" />
            <span className="text-lg">{formatDate(news.data)}</span>
          </div>

          <div className="flex flex-wrap gap-2 mb-8">
            {news.categorias.map((categoria, index) => (
              <span
                key={index}
                className="inline-flex items-center px-3 py-1 rounded-full text-sm bg-blue-100 text-blue-800"
              >
                <Tag className="h-4 w-4 mr-1" />
                {categoria}
              </span>
            ))}
          </div>

          <div className="prose prose-lg max-w-none">
            <p className="text-gray-700 leading-relaxed text-lg">
              {news.conteudo}
            </p>
          </div>
        </CardContent>
      </Card>

      <Comments comments={news.comentarios} />
    </div>
  )
}

export default NewsDetailPage

