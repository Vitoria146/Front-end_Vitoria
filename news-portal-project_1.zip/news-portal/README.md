# NewsPortal - Portal de Notícias

Um portal de notícias moderno desenvolvido com React, Vite, React Router e Tailwind CSS.

## 🚀 Tecnologias Utilizadas

- **React 19** - Biblioteca JavaScript para construção de interfaces
- **Vite** - Build tool e dev server ultra-rápido
- **React Router DOM** - Roteamento para aplicações React
- **Tailwind CSS** - Framework CSS utilitário
- **Lucide React** - Ícones modernos
- **shadcn/ui** - Componentes de UI reutilizáveis

## 📋 Funcionalidades

### ✅ Requisitos Implementados

1. **Organização do Projeto**
   - Estrutura de pastas bem organizada
   - Tipagem adequada com PropTypes implícito
   - Componentes reutilizáveis e modulares

2. **Estrutura das Notícias**
   - `id` - Identificador único
   - `titulo` - Título da notícia
   - `data` - Data de publicação
   - `conteudo` - Conteúdo completo da notícia
   - `imagem` - Placeholder para imagens
   - `categorias` - Array de categorias
   - `comentarios` - Array de objetos com nome e texto

3. **Home Page**
   - Lista de 10 notícias de um array estático
   - Mensagem "Nenhum artigo encontrado" quando não há resultados
   - Campo de busca que filtra por:
     - Título
     - Conteúdo
     - Categorias

4. **Visualização da Notícia**
   - Página completa da notícia ao clicar
   - Componente de comentários isolado
   - Carregamento dos comentários após delay (simulando API)
   - Navegação de volta para home page

5. **Design e UX**
   - Layout responsivo para desktop e mobile
   - Design moderno com gradientes e animações
   - Hover effects e transições suaves
   - Tipografia clara e hierarquia visual

## 🎨 Design

O portal utiliza um design moderno com:
- Paleta de cores azul/roxo com gradientes
- Cards com sombras e efeitos hover
- Layout em grid responsivo
- Ícones do Lucide React
- Componentes do shadcn/ui

## 🚀 Como Executar

### Pré-requisitos
- Node.js 18+ 
- pnpm (recomendado) ou npm

### Instalação e Execução

```bash
# Clone o repositório
git clone <url-do-repositorio>

# Entre no diretório
cd news-portal

# Instale as dependências
pnpm install

# Execute o servidor de desenvolvimento
pnpm run dev

# Acesse no navegador
http://localhost:5173
```

### Build para Produção

```bash
# Gerar build de produção
pnpm run build

# Preview do build
pnpm run preview
```

## 📱 Responsividade

A aplicação é totalmente responsiva e funciona em:
- 📱 Mobile (320px+)
- 📱 Tablet (768px+) 
- 💻 Desktop (1024px+)

## 🔍 Funcionalidades de Busca

- Busca em tempo real conforme digitação
- Filtragem por título, conteúdo e categorias
- Mensagem amigável quando não há resultados
- Limpeza automática de filtros

## 💬 Sistema de Comentários

- Carregamento assíncrono dos comentários
- Loading state com spinner
- Layout organizado com ícones
- Suporte a múltiplos comentários por notícia

## 🎯 Próximas Melhorias

- [ ] Integração com API real
- [ ] Sistema de autenticação
- [ ] Adicionar/editar comentários
- [ ] Filtros por categoria
- [ ] Paginação das notícias
- [ ] Modo escuro/claro
- [ ] Compartilhamento social

## 👥 Desenvolvido por

- João Silva (RA: 12345678)
- Maria Santos (RA: 87654321) 
- Pedro Costa (RA: 11223344)

---

**Link da Aplicação:** [Em breve - será adicionado após deploy]

© 2024 NewsPortal - Portal de Notícias

