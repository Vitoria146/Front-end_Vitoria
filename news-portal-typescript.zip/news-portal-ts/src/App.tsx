import { useState } from 'react'
import './App.css'

// Tipos TypeScript
interface Comentario {
  nome: string
  texto: string
}

interface Noticia {
  id: number
  titulo: string
  data: string
  conteudo: string
  categorias: string[]
  comentarios: Comentario[]
}

// Dados das notícias
const noticias: Noticia[] = [
  {
    id: 1,
    titulo: "Nova tecnologia revoluciona o mercado",
    data: "2024-01-15",
    conteudo: "Uma nova tecnologia está transformando a forma como trabalhamos. Esta inovação promete aumentar a produtividade e facilitar o dia a dia das pessoas em todo o mundo.",
    categorias: ["Tecnologia", "Inovação"],
    comentarios: [
      { nome: "João Silva", texto: "Muito interessante!" },
      { nome: "Maria Santos", texto: "Excelente notícia!" }
    ]
  },
  {
    id: 2,
    titulo: "Descoberta científica surpreende pesquisadores",
    data: "2024-01-14",
    conteudo: "Cientistas fizeram uma descoberta que pode mudar nossa compreensão sobre o universo. Os resultados foram publicados em uma revista científica renomada.",
    categorias: ["Ciência", "Pesquisa"],
    comentarios: [
      { nome: "Pedro Costa", texto: "Incrível descoberta!" }
    ]
  },
  {
    id: 3,
    titulo: "Economia mostra sinais de recuperação",
    data: "2024-01-13",
    conteudo: "Os indicadores econômicos mostram uma tendência positiva para os próximos meses. Especialistas são otimistas quanto ao crescimento.",
    categorias: ["Economia", "Finanças"],
    comentarios: [
      { nome: "Ana Oliveira", texto: "Boas notícias para todos!" },
      { nome: "Carlos Mendes", texto: "Esperamos que continue assim." }
    ]
  },
  {
    id: 4,
    titulo: "Esporte brasileiro ganha destaque mundial",
    data: "2024-01-12",
    conteudo: "Atletas brasileiros conquistam medalhas em competição internacional. O país se destaca mais uma vez no cenário esportivo mundial.",
    categorias: ["Esporte", "Brasil"],
    comentarios: [
      { nome: "Lucia Ferreira", texto: "Orgulho do nosso país!" }
    ]
  },
  {
    id: 5,
    titulo: "Meio ambiente: nova lei de proteção",
    data: "2024-01-11",
    conteudo: "Foi aprovada uma nova lei que visa proteger o meio ambiente e promover a sustentabilidade. A medida é considerada um marco histórico.",
    categorias: ["Meio Ambiente", "Política"],
    comentarios: [
      { nome: "Roberto Lima", texto: "Muito importante para o futuro!" }
    ]
  },
  {
    id: 6,
    titulo: "Educação recebe novos investimentos",
    data: "2024-01-10",
    conteudo: "O governo anuncia novos investimentos na área da educação. Escolas e universidades serão beneficiadas com recursos adicionais.",
    categorias: ["Educação", "Governo"],
    comentarios: [
      { nome: "Fernanda Rocha", texto: "Educação é prioridade!" }
    ]
  },
  {
    id: 7,
    titulo: "Saúde: avanços na medicina",
    data: "2024-01-09",
    conteudo: "Novos tratamentos médicos mostram resultados promissores. Pacientes têm mais esperança de cura para doenças antes consideradas incuráveis.",
    categorias: ["Saúde", "Medicina"],
    comentarios: [
      { nome: "Marcos Alves", texto: "Esperança para muitas famílias!" }
    ]
  },
  {
    id: 8,
    titulo: "Cultura: festival movimenta a cidade",
    data: "2024-01-08",
    conteudo: "Um grande festival cultural está acontecendo na cidade, atraindo visitantes de todo o país. O evento celebra a diversidade artística nacional.",
    categorias: ["Cultura", "Arte"],
    comentarios: [
      { nome: "Sandra Dias", texto: "Que evento maravilhoso!" }
    ]
  },
  {
    id: 9,
    titulo: "Transporte público ganha melhorias",
    data: "2024-01-07",
    conteudo: "O sistema de transporte público da cidade recebe investimentos para melhorar a qualidade do serviço oferecido aos usuários.",
    categorias: ["Transporte", "Cidade"],
    comentarios: [
      { nome: "José Barbosa", texto: "Era muito necessário!" }
    ]
  },
  {
    id: 10,
    titulo: "Segurança: novos equipamentos instalados",
    data: "2024-01-06",
    conteudo: "A cidade instala novos equipamentos de segurança para proteger os cidadãos. As medidas fazem parte de um plano maior de segurança pública.",
    categorias: ["Segurança", "Cidade"],
    comentarios: [
      { nome: "Patricia Gomes", texto: "Segurança é fundamental!" },
      { nome: "Ricardo Souza", texto: "Muito bom para todos!" }
    ]
  }
]

function App(): JSX.Element {
  const [busca, setBusca] = useState<string>('')
  const [noticiaAtual, setNoticiaAtual] = useState<number | null>(null)
  const [comentariosCarregados, setComentariosCarregados] = useState<boolean>(false)

  // Filtrar notícias
  const noticiasFiltradas: Noticia[] = noticias.filter(noticia =>
    noticia.titulo.toLowerCase().includes(busca.toLowerCase()) ||
    noticia.conteudo.toLowerCase().includes(busca.toLowerCase()) ||
    noticia.categorias.some(categoria => 
      categoria.toLowerCase().includes(busca.toLowerCase())
    )
  )

  // Abrir notícia
  const abrirNoticia = (id: number): void => {
    setNoticiaAtual(id)
    setComentariosCarregados(false)
    // Simular carregamento dos comentários
    setTimeout(() => setComentariosCarregados(true), 1000)
  }

  // Voltar para home
  const voltarHome = (): void => {
    setNoticiaAtual(null)
    setComentariosCarregados(false)
  }

  // Se está vendo uma notícia específica
  if (noticiaAtual) {
    const noticia = noticias.find(n => n.id === noticiaAtual)
    
    if (!noticia) {
      return (
        <div className="min-h-screen bg-gray-100">
          <header className="bg-blue-600 text-white p-4">
            <h1 className="text-2xl font-bold">📰 Portal de Notícias</h1>
          </header>
          <div className="container mx-auto p-4 text-center">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Notícia não encontrada</h2>
            <button 
              onClick={voltarHome}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              ← Voltar para Home
            </button>
          </div>
        </div>
      )
    }
    
    return (
      <div className="min-h-screen bg-gray-100">
        {/* Header */}
        <header className="bg-blue-600 text-white p-4">
          <h1 className="text-2xl font-bold">📰 Portal de Notícias</h1>
        </header>

        {/* Conteúdo da notícia */}
        <div className="container mx-auto p-4 max-w-4xl">
          <button 
            onClick={voltarHome}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-6"
          >
            ← Voltar para Home
          </button>

          <div className="bg-white rounded-lg shadow-md p-6">
            <h1 className="text-3xl font-bold text-gray-800 mb-4">{noticia.titulo}</h1>
            <p className="text-gray-600 mb-4">📅 {noticia.data}</p>
            
            <div className="flex flex-wrap gap-2 mb-6">
              {noticia.categorias.map((categoria: string, index: number) => (
                <span key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded">
                  {categoria}
                </span>
              ))}
            </div>

            <p className="text-gray-700 leading-relaxed">{noticia.conteudo}</p>
          </div>

          {/* Comentários */}
          <div className="mt-6 p-4 bg-white rounded-lg shadow-md">
            <h3 className="text-lg font-semibold mb-4">💬 Comentários ({noticia.comentarios.length})</h3>
            
            {!comentariosCarregados ? (
              <p className="text-gray-500">Carregando comentários...</p>
            ) : (
              <div className="space-y-3">
                {noticia.comentarios.map((comentario: Comentario, index: number) => (
                  <div key={index} className="border-l-4 border-blue-200 pl-3">
                    <p className="font-semibold text-gray-800">👤 {comentario.nome}</p>
                    <p className="text-gray-600">{comentario.texto}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <footer className="bg-gray-800 text-white p-4 mt-8">
          <div className="container mx-auto text-center">
            <p>Desenvolvido por: João Silva (RA: 12345678), Maria Santos (RA: 87654321), Pedro Costa (RA: 11223344)</p>
          </div>
        </footer>
      </div>
    )
  }

  // Página inicial
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-blue-600 text-white p-4">
        <h1 className="text-2xl font-bold">📰 Portal de Notícias</h1>
      </header>

      {/* Conteúdo principal */}
      <div className="container mx-auto p-4">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold text-gray-800 mb-4">Bem-vindo ao Portal de Notícias</h2>
          <p className="text-gray-600">Fique por dentro das últimas notícias</p>
        </div>

        {/* Barra de busca */}
        <div className="max-w-md mx-auto mb-8">
          <div className="relative">
            <span className="absolute left-3 top-3 text-gray-400">🔍</span>
            <input
              type="text"
              placeholder="Buscar notícias..."
              value={busca}
              onChange={(e) => setBusca(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>

        {/* Lista de notícias */}
        {noticiasFiltradas.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📰</div>
            <h3 className="text-xl font-semibold text-gray-700 mb-2">Nenhum artigo encontrado</h3>
            <p className="text-gray-500">Tente ajustar sua busca ou navegue pelas categorias disponíveis.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {noticiasFiltradas.map((noticia: Noticia) => (
              <div 
                key={noticia.id}
                className="bg-white rounded-lg shadow-md p-4 cursor-pointer hover:shadow-lg transition-shadow"
                onClick={() => abrirNoticia(noticia.id)}
              >
                <h3 className="text-lg font-semibold mb-2">{noticia.titulo}</h3>
                <p className="text-gray-600 text-sm mb-2">📅 {noticia.data}</p>
                <p className="text-gray-700 mb-3">
                  {noticia.conteudo.length > 50 ? noticia.conteudo.substring(0, 50) + '...' : noticia.conteudo}
                </p>
                <div className="flex flex-wrap gap-1">
                  {noticia.categorias.map((categoria: string, index: number) => (
                    <span key={index} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                      {categoria}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="bg-gray-800 text-white p-4 mt-8">
        <div className="container mx-auto text-center">
          <p>Desenvolvido por: João Silva (RA: 12345678), Maria Santos (RA: 87654321), Pedro Costa (RA: 11223344)</p>
        </div>
      </footer>
    </div>
  )
}

export default App

