# Portal de Notícias - ULTRA SIMPLES + TypeScript

Um portal de notícias extremamente simplificado desenvolvido com React, Vite, Tailwind CSS e **TypeScript**.

## 🎯 MÁXIMA SIMPLICIDADE + TIPAGEM FORTE

Este projeto foi desenvolvido para ser **o mais simples possível com TypeScript**:

- ✅ **UM ÚNICO ARQUIVO**: Todo código em `App.tsx` (300+ linhas)
- ✅ **TypeScript**: Tipagem forte para melhor manutenção
- ✅ **Apenas `useState`**: Sem hooks complexos ou bibliotecas extras
- ✅ **Sem componentes separados**: Tudo inline no App
- ✅ **Sem arquivos utilitários**: Removido `lib/utils.js` e `components/`
- ✅ **CSS mínimo**: Apenas `@import "tailwindcss"`
- ✅ **Emojis simples**: Sem bibliotecas de ícones
- ✅ **Dados no código**: Array de notícias direto no arquivo

## 🚀 Tecnologias

- **React** - Biblioteca JavaScript
- **TypeScript** - Tipagem estática
- **Vite** - Build tool
- **Tailwind CSS** - Framework CSS (apenas o básico)

## 📋 Funcionalidades

**Todos os requisitos implementados em código mínimo com TypeScript:**

1. **Estrutura das Notícias** (tipada)
   - `id: number`, `titulo: string`, `data: string`, `conteudo: string`
   - `categorias: string[]`, `comentarios: Comentario[]`
   - 10 notícias com dados completos

2. **Home Page**
   - Lista todas as notícias
   - Campo de busca funcional
   - Mensagem "Nenhum artigo encontrado"
   - Filtro por título, conteúdo e categorias

3. **Página de Detalhes**
   - Conteúdo completo da notícia
   - Comentários carregados após delay (1 segundo)
   - Botão para voltar à home

4. **Design Responsivo**
   - Layout em grid (1/2/3 colunas)
   - Cards com hover effects
   - Emojis para ícones

## 🔧 Tipos TypeScript

```typescript
interface Comentario {
  nome: string
  texto: string
}

interface Noticia {
  id: number
  titulo: string
  data: string
  conteudo: string
  categorias: string[]
  comentarios: Comentario[]
}
```

## ⏱️ Tempo de Desenvolvimento

**Estimativa: 1h15min** (com TypeScript)

- 15min - Setup e estrutura básica
- 30min - Código principal em um arquivo
- 15min - Tipagem TypeScript
- 10min - Funcionalidade de busca
- 5min - Navegação entre páginas

## 🚀 Como Executar

```bash
# Instalar dependências
cd news-portal-ts
pnpm install

# Executar
pnpm run dev

# Acessar
http://localhost:5175
```

## 📁 Estrutura Mínima

```
news-portal-ts/
├── src/
│   ├── App.tsx      # TODO O CÓDIGO AQUI (300+ linhas)
│   ├── App.css      # Apenas @import "tailwindcss"
│   ├── main.tsx     # Entry point padrão
│   └── index.css    # Vazio
├── tsconfig.json    # Configuração TypeScript
├── index.html       # HTML básico
├── package.json     # Dependências mínimas
└── README.md        # Este arquivo
```

## 📱 Responsividade

- Mobile: 1 coluna
- Tablet: 2 colunas  
- Desktop: 3 colunas

## 🎯 Vantagens do TypeScript

- ✅ **Tipagem forte**: Previne erros em tempo de compilação
- ✅ **IntelliSense**: Melhor autocomplete no editor
- ✅ **Refatoração segura**: Mudanças com mais confiança
- ✅ **Documentação viva**: Tipos servem como documentação
- ✅ **Manutenibilidade**: Código mais fácil de manter

## 👥 Desenvolvido por

- João Silva (RA: 12345678)
- Maria Santos (RA: 87654321)
- Pedro Costa (RA: 11223344)

---

**O projeto React + TypeScript mais simples possível para aprendizado!**

