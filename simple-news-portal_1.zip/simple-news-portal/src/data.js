// Dados simples das notícias
export const noticias = [
  {
    id: 1,
    titulo: "Nova tecnologia revoluciona o mercado",
    data: "2024-01-15",
    conteudo: "Uma nova tecnologia está transformando a forma como trabalhamos. Esta inovação promete aumentar a produtividade e facilitar o dia a dia das pessoas em todo o mundo.",
    categorias: ["Tecnologia", "Inovação"],
    comentarios: [
      { nome: "João Silva", texto: "Muito interessante!" },
      { nome: "Maria Santos", texto: "Excelente notícia!" }
    ]
  },
  {
    id: 2,
    titulo: "Descoberta científica surpreende pesquisadores",
    data: "2024-01-14",
    conteudo: "Cientistas fizeram uma descoberta que pode mudar nossa compreensão sobre o universo. Os resultados foram publicados em uma revista científica renomada.",
    categorias: ["Ciência", "Pesquisa"],
    comentarios: [
      { nome: "Pedro Costa", texto: "Incrível descoberta!" }
    ]
  },
  {
    id: 3,
    titulo: "Economia mostra sinais de recuperação",
    data: "2024-01-13",
    conteudo: "Os indicadores econômicos mostram uma tendência positiva para os próximos meses. Especialistas são otimistas quanto ao crescimento.",
    categorias: ["Economia", "Finanças"],
    comentarios: [
      { nome: "Ana Oliveira", texto: "Boas notícias para todos!" },
      { nome: "Carlos Mendes", texto: "Esperamos que continue assim." }
    ]
  },
  {
    id: 4,
    titulo: "Esporte brasileiro ganha destaque mundial",
    data: "2024-01-12",
    conteudo: "Atletas brasileiros conquistam medalhas em competição internacional. O país se destaca mais uma vez no cenário esportivo mundial.",
    categorias: ["Esporte", "Brasil"],
    comentarios: [
      { nome: "Lucia Ferreira", texto: "Orgulho do nosso país!" }
    ]
  },
  {
    id: 5,
    titulo: "Meio ambiente: nova lei de proteção",
    data: "2024-01-11",
    conteudo: "Foi aprovada uma nova lei que visa proteger o meio ambiente e promover a sustentabilidade. A medida é considerada um marco histórico.",
    categorias: ["Meio Ambiente", "Política"],
    comentarios: [
      { nome: "Roberto Lima", texto: "Muito importante para o futuro!" }
    ]
  },
  {
    id: 6,
    titulo: "Educação recebe novos investimentos",
    data: "2024-01-10",
    conteudo: "O governo anuncia novos investimentos na área da educação. Escolas e universidades serão beneficiadas com recursos adicionais.",
    categorias: ["Educação", "Governo"],
    comentarios: [
      { nome: "Fernanda Rocha", texto: "Educação é prioridade!" }
    ]
  },
  {
    id: 7,
    titulo: "Saúde: avanços na medicina",
    data: "2024-01-09",
    conteudo: "Novos tratamentos médicos mostram resultados promissores. Pacientes têm mais esperança de cura para doenças antes consideradas incuráveis.",
    categorias: ["Saúde", "Medicina"],
    comentarios: [
      { nome: "Marcos Alves", texto: "Esperança para muitas famílias!" }
    ]
  },
  {
    id: 8,
    titulo: "Cultura: festival movimenta a cidade",
    data: "2024-01-08",
    conteudo: "Um grande festival cultural está acontecendo na cidade, atraindo visitantes de todo o país. O evento celebra a diversidade artística nacional.",
    categorias: ["Cultura", "Arte"],
    comentarios: [
      { nome: "Sandra Dias", texto: "Que evento maravilhoso!" }
    ]
  },
  {
    id: 9,
    titulo: "Transporte público ganha melhorias",
    data: "2024-01-07",
    conteudo: "O sistema de transporte público da cidade recebe investimentos para melhorar a qualidade do serviço oferecido aos usuários.",
    categorias: ["Transporte", "Cidade"],
    comentarios: [
      { nome: "José Barbosa", texto: "Era muito necessário!" }
    ]
  },
  {
    id: 10,
    titulo: "Segurança: novos equipamentos instalados",
    data: "2024-01-06",
    conteudo: "A cidade instala novos equipamentos de segurança para proteger os cidadãos. As medidas fazem parte de um plano maior de segurança pública.",
    categorias: ["Segurança", "Cidade"],
    comentarios: [
      { nome: "Patricia Gomes", texto: "Segurança é fundamental!" },
      { nome: "Ricardo Souza", texto: "Muito bom para todos!" }
    ]
  }
];

