import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import './App.css'
import { noticias } from './data.js'

// Componente Header
function Header() {
  return (
    <header className="bg-blue-600 text-white p-4">
      <div className="container mx-auto">
        <h1 className="text-2xl font-bold">📰 Portal de Notícias</h1>
      </div>
    </header>
  )
}

// Componente Footer
function Footer() {
  return (
    <footer className="bg-gray-800 text-white p-4 mt-8">
      <div className="container mx-auto text-center">
        <p>Desenvolvido por: João Silva (RA: 12345678), Maria Santos (RA: 87654321), Pedro Costa (RA: 11223344)</p>
      </div>
    </footer>
  )
}

// Componente Card de Notícia
function NoticiaCard({ noticia, onClick }) {
  return (
    <div 
      className="bg-white rounded-lg shadow-md p-4 cursor-pointer hover:shadow-lg transition-shadow"
      onClick={() => onClick(noticia.id)}
    >
      <h3 className="text-lg font-semibold mb-2">{noticia.titulo}</h3>
      <p className="text-gray-600 text-sm mb-2">📅 {noticia.data}</p>
      <p className="text-gray-700 mb-3">
        {noticia.conteudo.length > 50 ? noticia.conteudo.substring(0, 50) + '...' : noticia.conteudo}
      </p>
      <div className="flex flex-wrap gap-1">
        {noticia.categorias.map((categoria, index) => (
          <span key={index} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
            {categoria}
          </span>
        ))}
      </div>
    </div>
  )
}

// Componente de Comentários
function Comentarios({ comentarios }) {
  const [carregando, setCarregando] = useState(true)

  // Simula carregamento dos comentários
  useState(() => {
    setTimeout(() => setCarregando(false), 1000)
  }, [])

  if (carregando) {
    return (
      <div className="mt-6 p-4 bg-white rounded-lg shadow-md">
        <h3 className="text-lg font-semibold mb-4">💬 Comentários</h3>
        <p className="text-gray-500">Carregando comentários...</p>
      </div>
    )
  }

  return (
    <div className="mt-6 p-4 bg-white rounded-lg shadow-md">
      <h3 className="text-lg font-semibold mb-4">💬 Comentários ({comentarios.length})</h3>
      {comentarios.length === 0 ? (
        <p className="text-gray-500">Nenhum comentário ainda.</p>
      ) : (
        <div className="space-y-3">
          {comentarios.map((comentario, index) => (
            <div key={index} className="border-l-4 border-blue-200 pl-3">
              <p className="font-semibold text-gray-800">👤 {comentario.nome}</p>
              <p className="text-gray-600">{comentario.texto}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}

// Página Home
function HomePage({ onNoticiaClick }) {
  const [busca, setBusca] = useState('')

  // Filtrar notícias
  const noticiasFiltradas = noticias.filter(noticia =>
    noticia.titulo.toLowerCase().includes(busca.toLowerCase()) ||
    noticia.conteudo.toLowerCase().includes(busca.toLowerCase()) ||
    noticia.categorias.some(categoria => 
      categoria.toLowerCase().includes(busca.toLowerCase())
    )
  )

  return (
    <div className="container mx-auto p-4">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-4">Bem-vindo ao Portal de Notícias</h2>
        <p className="text-gray-600">Fique por dentro das últimas notícias</p>
      </div>

      {/* Barra de busca */}
      <div className="max-w-md mx-auto mb-8">
        <div className="relative">
          <span className="absolute left-3 top-3 text-gray-400">🔍</span>
          <input
            type="text"
            placeholder="Buscar notícias..."
            value={busca}
            onChange={(e) => setBusca(e.target.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          />
        </div>
      </div>

      {/* Lista de notícias */}
      {noticiasFiltradas.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">📰</div>
          <h3 className="text-xl font-semibold text-gray-700 mb-2">Nenhum artigo encontrado</h3>
          <p className="text-gray-500">Tente ajustar sua busca ou navegue pelas categorias disponíveis.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {noticiasFiltradas.map(noticia => (
            <NoticiaCard 
              key={noticia.id} 
              noticia={noticia} 
              onClick={onNoticiaClick}
            />
          ))}
        </div>
      )}
    </div>
  )
}

// Página de Detalhes da Notícia
function NoticiaDetalhes({ noticiaId, onVoltar }) {
  const noticia = noticias.find(n => n.id === noticiaId)

  if (!noticia) {
    return (
      <div className="container mx-auto p-4 text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Notícia não encontrada</h2>
        <button 
          onClick={onVoltar}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
          ← Voltar para Home
        </button>
      </div>
    )
  }

  return (
    <div className="container mx-auto p-4 max-w-4xl">
      <button 
        onClick={onVoltar}
        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-6"
      >
        ← Voltar para Home
      </button>

      <div className="bg-white rounded-lg shadow-md p-6">
        <h1 className="text-3xl font-bold text-gray-800 mb-4">{noticia.titulo}</h1>
        <p className="text-gray-600 mb-4">📅 {noticia.data}</p>
        
        <div className="flex flex-wrap gap-2 mb-6">
          {noticia.categorias.map((categoria, index) => (
            <span key={index} className="bg-blue-100 text-blue-800 px-3 py-1 rounded">
              {categoria}
            </span>
          ))}
        </div>

        <div className="text-gray-700 leading-relaxed">
          <p>{noticia.conteudo}</p>
        </div>
      </div>

      <Comentarios comentarios={noticia.comentarios} />
    </div>
  )
}

// Componente principal App
function App() {
  const [paginaAtual, setPaginaAtual] = useState('home')
  const [noticiaAtual, setNoticiaAtual] = useState(null)

  const irParaNoticia = (id) => {
    setNoticiaAtual(id)
    setPaginaAtual('detalhes')
  }

  const voltarParaHome = () => {
    setPaginaAtual('home')
    setNoticiaAtual(null)
  }

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      
      <main className="min-h-screen">
        {paginaAtual === 'home' ? (
          <HomePage onNoticiaClick={irParaNoticia} />
        ) : (
          <NoticiaDetalhes 
            noticiaId={noticiaAtual} 
            onVoltar={voltarParaHome} 
          />
        )}
      </main>

      <Footer />
    </div>
  )
}

export default App
