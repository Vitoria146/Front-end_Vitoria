# Portal de Notícias - Versão Simples

Um portal de notícias simples desenvolvido com React, Vite e Tailwind CSS.

## 🚀 Tecnologias

- **React** - Biblioteca JavaScript
- **Vite** - Build tool
- **Tailwind CSS** - Framework CSS
- **useState** - Hook básico do React

## 📋 Funcionalidades

✅ **Todos os requisitos implementados:**

1. **Estrutura das Notícias**
   - `id`, `titulo`, `data`, `conteudo`, `categorias`, `comentarios`
   - 10 notícias com dados completos

2. **Home Page**
   - Lista todas as notícias
   - Campo de busca funcional
   - Mensagem "Nenhum artigo encontrado"
   - Filtro por título, conteúdo e categorias

3. **Página de Detalhes**
   - Conteúdo completo da notícia
   - Comentários carregados após delay
   - Botão para voltar à home

4. **Design Responsivo**
   - Layout em grid
   - Cards com hover effects
   - Emojis para ícones (sem bibliotecas externas)

## 🎯 Simplicidade

Este projeto foi desenvolvido para ser **simples e didático**:

- ✅ Apenas `useState` (sem hooks complexos)
- ✅ Sem `useMemo` ou otimizações avançadas
- ✅ Sem bibliotecas de UI externas
- ✅ Componentes em um único arquivo
- ✅ Navegação com estado simples
- ✅ Emojis ao invés de ícones
- ✅ CSS com Tailwind básico

## ⏱️ Tempo de Desenvolvimento

**Estimativa: 1h30min**

- 20min - Setup e estrutura básica
- 30min - Componentes e layout
- 20min - Funcionalidade de busca
- 15min - Navegação entre páginas
- 5min - Ajustes finais

## 🚀 Como Executar

```bash
# Instalar dependências
cd simple-news-portal
pnpm install

# Executar
pnpm run dev

# Acessar
http://localhost:5174
```

## 📱 Responsividade

- Mobile: 1 coluna
- Tablet: 2 colunas  
- Desktop: 3 colunas

## 👥 Desenvolvido por

- João Silva (RA: 12345678)
- Maria Santos (RA: 87654321)
- Pedro Costa (RA: 11223344)

---

**Projeto simples e funcional para aprendizado de React básico!**

